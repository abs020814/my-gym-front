import {useState, useEffect } from 'react'
import Comment from './Comment' 
import NewCommentForm from './NewCommentForm' 

const Comments = ({articleId}) => {
    const [comments, setComments] = useState([])

    useEffect(() => {
        const fetchComments = async () => {
            try {
                const response = await fetch(process.env.REACT_APP_API_URL + '/posts/' + articleId + '/comments' )
                const data = await response.json()
                console.log(data)
                setComments(data.comments)
            } catch (error) {console.error(error.message)}
        }

        fetchComments()
    }, [])

    const handleCommentDelete = (commentId) => {
        setComments(comments => comments.filter(comment => comment._id !== commentId))
    }

    return (
        <section>
            <h2>Comentarios:</h2>
            <NewCommentForm articleId={articleId} />
            { comments.map( comment => (
                <Comment key={comment._id} comment={comment} onDelete={handleCommentDelete}/>
            ))}
        </section>
    )

}
export default Comments