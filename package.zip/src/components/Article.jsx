import {useState, useEffect } from 'react'
import Comments from './Comments'

const Article = ({articleId}) => {
    const [post, setPost] = useState([])

    useEffect(() => {
        const fetchPost = async () => {
            try {
                const response = await fetch(process.env.REACT_APP_API_URL + '/posts/' + articleId)
                const data = await response.json()
                setPost(data)
            } catch (error) {console.error(error.message)}
        }

        fetchPost()
    }, [])
    return (
        <>
            <h2> {post.title} </h2>
            <h3> {post.content} </h3>
            <hr></hr>
            <Comments articleId={articleId} />
        </>
        
    )
}
export default Article