

const Comment = ({ articleId, comment , onDelete }) => {
     const handleDelete = async () => {
        try {
            const response = await fetch(process.env.REACT_APP_API_URL + '/posts/' + articleId + '/comments/' + comment._id , {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json'
                }
            })
            if (!response.ok) {
                console.error('Response was not OK')
            }

            alert('Comment deleted')

            onDelete(comment._id)

        } catch (error) { console.error(error.message)}
    }
 
    return (
        <article>
            <h2>{comment.content}</h2>
            <p>{comment.authorName}</p>
            <p>{comment.authorEmail}</p>
            <button onClick={handleDelete}>Deletecomment</button>
        </article>
    )
}
export default Comment