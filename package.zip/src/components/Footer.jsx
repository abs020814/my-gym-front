
const Footer = () => {
    /* const postItems = []
    posts.forEach( (post) => {
        postItems.push ( 
            <li><a href={`#${post.id}`}>{post.title}</a></li>)
    }) */
    return (
        <footer>
            <p>&copy; MyBlog 2024</p>
        </footer>
    )

}
export default Footer