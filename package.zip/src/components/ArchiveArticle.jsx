import { Link } from 'react-router-dom'


const ArchiveArticle = ({post, onDelete}) => {
    const handleDelete = async () => {
        try {
            const response = await fetch(process.env.REACT_APP_API_URL + '/posts/' + post._id, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json'
                }
            })
            if (!response.ok) {
                console.error('Response was not OK')
            }

            alert('Post deleted')

            onDelete(post._id)

        } catch (error) { console.error(error.message)}
    }

    return (
        <article>
            <h2>{post.title}</h2>
            <p>{post.authorName}</p>
            <p>{post.extract}</p>
            <Link to={`/posts/${post._id}`}>Read more</Link>
            <button onClick={handleDelete}>Delete</button>
        </article>
    )
}
export default ArchiveArticle