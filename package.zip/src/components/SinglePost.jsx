import { useParams } from 'react-router-dom'
import Header from './Header' 
import Footer from './Footer.jsx'
import Article from './Article' 

const SinglePost = () => {
    const { articleId } = useParams()
    return(
        <>
            <Header />
            <Article articleId={articleId} />
            <Footer />
        </>
    )
}
export default SinglePost