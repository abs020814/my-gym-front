import Header from './Header'
import Footer from './Footer.jsx'
import NewPostForm from './NewPostForm.jsx'

const NewPost = () => {
    return (
        <>
        <Header />
        <NewPostForm />
        <Footer />
        </>
    )

}
export default NewPost