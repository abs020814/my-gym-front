import { Link } from 'react-router-dom'

const Header = () => {
    /* const postItems = []
    posts.forEach( (post) => {
        postItems.push ( 
            <li><a href={`#${post.id}`}>{post.title}</a></li>)
    }) */
    return (
        <header>
            <h1 id="title">Mi Blog</h1>
            <Link to="/new-post">New post</Link>
            <Link to="/"> Home</Link>
        </header>
    )

}
export default Header