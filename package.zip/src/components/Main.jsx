
import BlogPosts from './BlogPosts'

const Main = () => {
    return (
        <main>
            <BlogPosts />            
        </main>
    )

}
export default Main